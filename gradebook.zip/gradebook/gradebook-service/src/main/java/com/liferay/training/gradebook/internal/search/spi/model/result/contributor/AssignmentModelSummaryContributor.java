package com.liferay.training.gradebook.internal.search.spi.model.result.contributor;

import com.liferay.asset.util.AssetHelper;
import com.liferay.petra.string.StringPool;
import com.liferay.portal.kernel.search.Document;
import com.liferay.portal.kernel.search.Field;
import com.liferay.portal.kernel.search.Summary;
import com.liferay.portal.kernel.util.LocaleUtil;
import com.liferay.portal.kernel.util.LocalizationUtil;
import com.liferay.portal.search.spi.model.result.contributor.ModelSummaryContributor;
import com.liferay.portal.security.lang.DoPrivilegedBean;

import java.util.Locale;

import org.osgi.service.component.annotations.Component;

/**
 * 
 * @author hgrahul
 * The Model Summary Contributor Constructs The Result Summary, Including The Field To Display
 */
@Component(immediate = true, property = "indexer.class.name=com.liferay.training.gradebook.model.Assignment", service = ModelSummaryContributor.class)
public class AssignmentModelSummaryContributor implements ModelSummaryContributor{
	@Override
	public Summary getSummary(Document document, Locale locale, String snippet) {
		String languageId = LocaleUtil.toLanguageId(locale);
		
		// Need to build summary for the final result viewing
		return createSummary(document, LocalizationUtil.getLocalizedName(Field.DESCRIPTION, languageId), LocalizationUtil.getLocalizedName(Field.TITLE, languageId));
	}
	
	private Summary createSummary(Document document, String descriptionField, String titleField) {
		String prefix = Field.SNIPPET + StringPool.UNDERLINE;
		
		Summary summary = new Summary(
			document.get(prefix + titleField, titleField),
			document.get(prefix + descriptionField, descriptionField)
		);
		
		summary.setMaxContentLength(AssetHelper.ASSET_ENTRY_ABSTRACT_LENGTH);
		
		return summary;
	}
}
